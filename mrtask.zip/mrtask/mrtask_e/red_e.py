import sys
from datetime import datetime
# calculationg the different pickup location
different_pickup_loaction={}
different_pickup_tips={}
time_difference={}
for line in sys.stdin:
    line = line.strip()
    PULocationID, tip_amount,total_amount = line.split('\t')

    if PULocationID in different_pickup_loaction:
        different_pickup_loaction[PULocationID].append(total_amount)
    else:
        different_pickup_loaction[PULocationID]=[]
        different_pickup_loaction[PULocationID].append(total_amount)
        
    if PULocationID in different_pickup_tips:
        different_pickup_tips[PULocationID].append(tip_amount)
    else:
        different_pickup_tips[PULocationID]=[]
        different_pickup_tips[PULocationID].append(tip_amount)
final_calculation={}
for i in different_pickup_loaction.keys():
    #print(different_pickup_loaction[i])
    total_tips=0
    total_amount=0
    for j in different_pickup_loaction[i]:
        total_amount=total_amount+float(j)
    for k in different_pickup_tips[i]:
            total_tips=total_tips+float(k)
    final_calculation[i]=total_tips/total_amount

final_calculation1=list(final_calculation.keys())
final_calculation1.sort()
sorted_final_Calculation={m:final_calculation[m] for m in final_calculation1}
print(sorted_final_Calculation)

