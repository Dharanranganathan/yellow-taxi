import sys
for line in sys.stdin:
    line = line.strip()
    line = line.split(",")
    if(len(line)>=2):
        VendorID = line[0]
        tpep_pickup_datetime = line[1]
        tpep_dropoff_datetime = line[2]
        passenger_count = line[3]
        trip_distance = line[4]
        RatecodeID = line[5]
        store_and_fwd_flag = line[6]
        PULocationID = line[7]
        DOLocationID = line[8]
        payment_type = line[9]
        fare_amount = line[10]
        extra = line[11]
        mta_tax = line[12]
        tip_amount = line[13]
        tolls_amount = line[14]
        improvement_surcharge = line[15]
        total_amount = line[16]
        congestion_surcharge = line[17]
        airport_fee = line[18]
        print('%s\t%s\t%s' % (PULocationID, tip_amount,total_amount))

