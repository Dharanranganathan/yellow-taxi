import sys
from datetime import datetime
# calculationg the count of different pickup location
different_pickup_loaction={}
time_difference={}
for line in sys.stdin:
    line = line.strip()
    PULocationID, tpep_pickup_datetime,tpep_dropoff_datetime = line.split('\t')

    if PULocationID in different_pickup_loaction:
        different_pickup_loaction[PULocationID]=different_pickup_loaction[PULocationID]+1
    else:
        different_pickup_loaction[PULocationID]=1
    start_time=tpep_pickup_datetime
    end_time=tpep_dropoff_datetime
    t1 = str(start_time)
    t2 = str(end_time)
    # print(t1)
    delta = datetime.strptime(t2, '%m-%d-%Y %M:%S') - datetime.strptime(t1, '%m-%d-%Y %M:%S')
    delta = str(delta)
    #print(delta)
    delta=delta[5:7]
    delta1=int(delta)
    # print(delta1)
    if PULocationID in time_difference:
        time_difference[PULocationID].append(int(delta1))
    else:
        time_difference[PULocationID]=[]
        time_difference[PULocationID].append(delta1)
#print(different_pickup_loaction)
final_calculation={}
for i in different_pickup_loaction.keys():
    #print(different_pickup_loaction[i])
    sum1=0
    for k in time_difference[i]:
            sum1=sum1+int(k)
    # print(sum1)
    final_calculation[i]=sum1/different_pickup_loaction[i]
for i in final_calculation.keys():
print(“The PULocationID : ”,i,”Average trip generated : ”,final_calculation[i])

