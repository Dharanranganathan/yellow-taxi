import sys
payment_type_count = {}
for line in sys.stdin:
    line = line.strip()

    payment_type, total_amount = line.split('\t')

    if payment_type in payment_type_count:
        payment_type_count[payment_type]=payment_type_count[payment_type]+1
    else:
        payment_type_count[payment_type]=1
for i in payment_type_count:
            print("payment type",i,"count of user",payment_type_count[i])
