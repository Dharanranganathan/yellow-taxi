from mrjob.job import MRJob
from mrjob.step import MRStep
from datetime import datetime

class RevenueByHourAndDayJob(MRJob):

    def mapper(self, _, line):
        # Skip the header row
        if "vendor_id" in line:
            return

        # Split the input line into fields
        fields = line.split(",")
        pickup_datetime = fields[1]
        trip_distance = float(fields[4])
        fare_amount = float(fields[11])

        # Convert the pickup datetime string into a datetime object
        pickup_datetime_obj = datetime.strptime(pickup_datetime, "%Y-%m-%d %H:%M:%S")

        # Emit the revenue as the output value, keyed by hour and day of the week
        hour_of_day = pickup_datetime_obj.hour
        day_of_week = pickup_datetime_obj.weekday()
        is_weekend = day_of_week >= 5
        is_night = hour_of_day < 6 or hour_of_day >= 20
        output_key = (day_of_week, is_weekend, is_night, hour_of_day)
        output_value = trip_distance * fare_amount
        yield output_key, output_value

    def reducer(self, key, values):
        # Sum up the total revenue for each hour of the day and day of the week
        total_revenue = sum(values)
print(“The PULocationID : ”,i,”Average trip generated : ”,final_calculation[i])
if __name__ == '__main__':
    RevenueByHourAndDayJob.run()

