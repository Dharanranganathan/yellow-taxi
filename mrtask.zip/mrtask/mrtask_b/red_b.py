import sys
PULocation = {}
max_price=[]
for line in sys.stdin:
    line = line.strip()

    PULocationID, total_amount = line.split('\t')

    if PULocationID in PULocation:
        PULocation[PULocationID].append(total_amount)
    else:
        PULocation[PULocationID] = []
        PULocation[PULocationID].append(total_amount)
PULocation1 = {}
for i in PULocation.keys():
            sum1=0
            for j in PULocation[i]:
                #print(j)
                sum1=float(j)+sum1
            PULocation1[i]=sum1
key = [k for k, v in PULocation1.items() if v == max(PULocation1.values())][0]
value = [v for k, v in PULocation1.items() if v == max(PULocation1.values())][0]
print(" Pulocation with more revenue",key,"Amount generated" ,value)
